
close all;

pkg load ltfat;
pkg load signal;
graphics_toolkit('fltk');

% identifiy availabe hardware interfaces
dev = blockdevices()

% signal params
BLKlength = power(2,10);
fs = 96e3;
T = 1;
f1 = 750;
f2 = 3000;
a = 0.5;
N = T*fs; % number of samples
nBLK = floor(N/BLKlength); % number of blocks
t = linspace(0,T,N);

sine1 = a * sin(2*pi*f1*t);
sine2 = a * sin(2*pi*f2*t);

stimulus = zeros([N,2]);
stimulus(:,1) = sine1';
stimulus(:,2) = sine2';
resp = zeros([N,2]);

% open audio devices
block('playrec', 'fs', 48000, 'L', BLKlength, 'devid', [0,0], 'playch', [1,2], 'recch', [1,2], 'loadind', 'nobar'); 

% send stimuls and receive response via ASIO interface
i = 1;
while(i<=nBLK)
	blockplay(stimulus(((i-1)*BLKlength+1):(i*BLKlength), :)); 
	resp(((i-1)*BLKlength+1):(i*BLKlength), :) = blockread(BLKlength); 
	i = i+1;
end

% close devices
blockdone(); 

% display recorded data
figure(1);
plot(t/1e-3,resp(:,1),t/1e-3, resp(:,2)); 
xlabel('time in sec');
ylabel('amplitude, 1.0=100%FS');
title('my first test signal');
grid;

% apply window
figure(2)
win = firwin('hanning',power(2,16));
a = resp(60*nBLK:60*nBLK+power(2,16)-1,:).*(1-win);
hold on
plot(a(:,1));
plot(a(:,2));
hold off
xlabel('time in sec');
ylabel('amplitude, 1.0=100%FS');
grid;

% calc fft
figure(3);
hold on
semilogx(20*log10(abs(fft(a(:,1)))));  
semilogx(20*log10(abs(fft(a(:,2)))));  
hold off
xlabel('frequency');
ylabel('amplitude');
grid;



